from django.shortcuts import render,redirect
from django.http import HttpResponse

#  { }  Create your views here.

def home(request):
    return render(request,'user\home.html',context={} )

def about(request):
    return render(request,'user\\about.html',context={} )    

def inspiration(request):
    return render(request,'user\inspiration.html',context={} )    