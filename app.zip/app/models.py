from django.db import models
from embed_video.fields import EmbedVideoField


class Slide(models.Model):
    image1=models.ImageField(upload_to='img',blank=True,null=True)
    title1=models.CharField(max_length=20,blank=True,null=True)
    sub_title1=models.CharField(max_length=20,blank=True,null=True)
    link_facebook=models.URLField(blank=True,null=True)
    link_skype=models.URLField(blank=True,null=True)
    image2=models.ImageField(upload_to='img',blank=True,null=True)
    title2=models.CharField(max_length=20,blank=True,null=True)
    sub_title2=models.CharField(max_length=20,blank=True,null=True)
    image3=models.ImageField(upload_to='img',blank=True,null=True)
    title3=models.CharField(max_length=20,blank=True,null=True)
    sub_title3=models.CharField(max_length=20,blank=True,null=True) 
    def __str__(self):
        return self.title1 

class About(models.Model):
    image=models.ImageField(upload_to='img',blank=True,null=True)
    title=models.CharField(max_length=20,blank=True,null=True)
    sub_title=models.CharField(max_length=20,blank=True,null=True)  
    image_rond=models.ImageField(upload_to='img',blank=True,null=True)
    part1=models.TextField(blank=True,null=True)
    part2=models.TextField(blank=True,null=True)
    multiple_image_gallery=models.ImageField(upload_to='img',blank=True,null=True)
 
    def __str__(self):
        return self.title

class Inspiration(models.Model):
    image=models.ImageField(upload_to='img',blank=True,null=True)
    theme=models.CharField(max_length=20,blank=True,null=True)
    link_skype=models.URLField(blank=True,null=True)
    content=models.TextField(blank=True,null=True)
    def __str__(self):
        return self.theme 

class Project(models.Model):
    image=models.ImageField(upload_to='img',blank=True,null=True)
    title=models.CharField(max_length=20,blank=True,null=True)
    link_skype=models.URLField(blank=True,null=True)
    content=models.TextField(blank=True,null=True)
    def __str__(self):
        return self.title


class Plan_annuel(models.Model):
    title=models.CharField(max_length=17,blank=True,null=True)
    date=models.DateField(blank=True,null=True)
    link_skype=models.URLField(blank=True,null=True)
    content=models.TextField(blank=True,null=True)
    def __str__(self):
        return self.title

class Member(models.Model):
    image=models.ImageField(upload_to='img',blank=True,null=True)
    name=models.CharField(max_length=20,blank=True,null=True)
    link_facebook=models.URLField(blank=True,null=True)
    link_insta=models.URLField(blank=True,null=True)
    link_twitter=models.URLField(blank=True,null=True)

    content=models.TextField(blank=True,null=True)
    def __str__(self):
        return self.title
class Videos(models.Model):
      video = EmbedVideoField()

class Verset(models.Model):
    verset=models.CharField(max_length=20,blank=True,null=True)
    verset_content=models.TextField(blank=True,null=True)
    image_square=models.ImageField(upload_to='img',blank=True,null=True)
    meditation_verset=models.TextField(blank=True,null=True)
 
    def __str__(self):
        return self.verset        

class Contact(models.Model):
    name=models.CharField(max_length=20,blank=True,null=True)
    email=models.EmailField(blank=True,null=True)
    subject=models.CharField(max_length=45,blank=True,null=True)
    message=models.TextField(blank=True,null=True)
 
    def __str__(self):
        return self.verset 


class Ms_info(models.Model):
    email=models.EmailField(blank=True,null=True)
    phone=models.CharField(max_length=20,blank=True,null=True)
    address=models.CharField(max_length=20,blank=True,null=True)
    contact_text=models.TextField(blank=True,null=True)
    def __str__(self):
        return self.phone

