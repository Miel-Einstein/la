from django.contrib import admin
from .models import *

admin.site.register(Slide)
admin.site.register(Verset)
admin.site.register(Project)
admin.site.register(About)
admin.site.register(Contact)
admin.site.register(Ms_info)
admin.site.register(Inspiration)
admin.site.register(Member)
admin.site.register(Plan_annuel)